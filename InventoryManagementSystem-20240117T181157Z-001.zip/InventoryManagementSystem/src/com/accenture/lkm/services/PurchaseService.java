package com.accenture.lkm.services;

import com.accenture.lkm.business.bean.PurchaseBean;

public interface PurchaseService {
	public PurchaseBean savePurchaseDetails(PurchaseBean purchaseBean);

}
